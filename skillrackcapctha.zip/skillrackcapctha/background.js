// Helper to convert base64 string back into a file blob for the POST request
function base64ToBlob(base64) {
    const arr = base64.split(',');
    const mime = arr[0].match(/:(.*?);/)[1];
    const bstr = atob(arr[1]);
    let n = bstr.length;
    const u8arr = new Uint8Array(n);
    while (n--) {
        u8arr[n] = bstr.charCodeAt(n);
    }
    return new Blob([u8arr], { type: mime });
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "solveCaptcha") {
        const blob = base64ToBlob(request.base64);
        
        const formData = new FormData();
        formData.append("image", blob, "captcha.png");

        fetch("https://thefallenmaster.pythonanywhere.com/solve", {
            method: "POST",
            body: formData
        })
        .then(response => response.text()) // Using .text() because your API returns raw text
        .then(text => {
            sendResponse({ answer: text });
        })
        .catch(error => {
            sendResponse({ error: error.message });
        });

        // Return true indicates we will send the response asynchronously
        return true; 
    }
});
