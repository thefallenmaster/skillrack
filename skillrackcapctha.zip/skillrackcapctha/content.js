function extractAndSolve() {
    const inputField = document.getElementById('capval');
    if (!inputField) return; // Exit if the input field isn't on the page

    // Find the base64 image inside the widget panel
    const imgElement = document.querySelector('.ui-outputpanel img[src^="data:image/png;base64"]');
    if (!imgElement) return;

    const base64Data = imgElement.src;

    // Send the base64 string to the background script to bypass CORS
    chrome.runtime.sendMessage({ action: "solveCaptcha", base64: base64Data }, (response) => {
        if (response && response.answer) {
            // Fill the input field with the raw text answer (e.g., "50")
            inputField.value = response.answer.trim();
            console.log("Captcha solved:", response.answer);
        } else {
            console.error("Captcha solve error:", response.error);
        }
    });
}

// PrimeFaces sometimes loads elements dynamically. 
// A slight delay ensures the DOM is fully rendered before grabbing the image.
window.addEventListener('load', () => {
    setTimeout(extractAndSolve, 800);
});

