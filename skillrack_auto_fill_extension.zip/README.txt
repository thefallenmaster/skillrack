SkillRack Auto Solution Filler
==============================

Use only on a SkillRack deployment you own/administer.

INSTALL
-------
1. Extract this ZIP.
2. Open brave://extensions/ (or chrome://extensions/).
3. Enable Developer mode.
4. Click "Load unpacked".
5. Select the extracted skillrack_auto_fill_extension folder.
6. Reload the SkillRack page.

BEHAVIOR
--------
When #solnC pre and the C editor (#ctracktxtCode / #txtCode) are both present:

- The solution is read directly from #solnC pre.
- The extension tries to copy the solution to the normal browser clipboard.
- The site's Ace command "bte" is removed.
- The site's Ace exec paste blocker is removed where Ace exposes the event API.
- The site's jQuery document cut/copy/paste blocker is removed.
- The solution is transferred directly into Ace; clipboard paste is not required.
- The hidden #txtCode textarea is updated FIRST, which prevents the supplied
  SkillRack change handler from resetting Ace because of its >30-character check.
- On refresh or later DOM/Ace initialization, detection runs again automatically.

SMART MODE
----------
The default is smartMode=true.

If the editor is the standard starter template/empty main(), the complete official
solution replaces it.

If the editor already contains custom code, the extension preserves code outside
main() and replaces only main() with the official solution. This is intended to
preserve custom headers/helper functions while putting the official answer where
the program body belongs.

No Selenium is required for this extension itself.
