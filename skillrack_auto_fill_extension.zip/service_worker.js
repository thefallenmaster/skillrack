
"use strict";

chrome.runtime.onMessage.addListener((message, sender) => {
  if (message?.type !== "SKILLRACK_AUTO_FILL") return;

  const tabId = sender?.tab?.id;
  if (typeof tabId !== "number") return;

  chrome.scripting.executeScript({
    target: { tabId, frameIds: [sender.frameId ?? 0] },
    world: "MAIN",
    func: autoFillInPageContext,
    args: [
      String(message.solution ?? ""),
      Boolean(message.smartMode)
    ]
  }).catch(error => {
    console.warn("[SkillRack Auto Filler] executeScript failed:", error);
  });
});

function autoFillInPageContext(solution, smartMode) {
  "use strict";

  if (!solution) return;

  const editor =
    window.txtCode ||
    (
      window.ace &&
      typeof window.ace.edit === "function" &&
      document.getElementById("ctracktxtCode")
        ? window.ace.edit("ctracktxtCode")
        : null
    );

  const hidden = document.getElementById("txtCode");
  const editorRoot = document.getElementById("ctracktxtCode");

  if (!editor || !hidden) {
    console.debug("[SkillRack Auto Filler] Ace editor not ready.");
    return;
  }

  // ----------------------------------------------------------
  // Remove the site's copy/paste keyboard blocker.
  // ----------------------------------------------------------
  try {
    editor.commands.removeCommand("bte");
  } catch (_) {}

  // The page added:
  // txtCode.commands.on("exec", function(e) { if paste ... })
  // Remove command-event listeners when Ace exposes the method.
  const commandManager = editor.commands;

  try {
    if (typeof commandManager.off === "function") {
      commandManager.off("exec");
    }
  } catch (_) {}

  try {
    if (typeof commandManager.removeEventListener === "function") {
      commandManager.removeEventListener("exec");
    }
  } catch (_) {}

  try {
    if (typeof commandManager.removeAllListeners === "function") {
      commandManager.removeAllListeners("exec");
    }
  } catch (_) {}

  // SkillRack's page-level jQuery handler:
  // $(document).bind("cut copy paste", function(e) { e.preventDefault(); });
  try {
    if (window.jQuery) {
      window.jQuery(document).off("cut copy paste");
      window.jQuery(document).off("cut");
      window.jQuery(document).off("copy");
      window.jQuery(document).off("paste");
    }
  } catch (_) {}

  // ----------------------------------------------------------
  // Calculate the code to place in Ace.
  //
  // SMART mode:
  // - Empty/starter editor -> use the full official solution.
  // - Existing custom code -> preserve everything outside main()
  //   and replace only the main() body with the official solution.
  // This avoids destroying custom headers/helper functions.
  // ----------------------------------------------------------

  function normalize(s) {
    return (s || "")
      .replace(/\r\n?/g, "\n")
      .trim();
  }

  function looksLikeStarter(s) {
    const n = normalize(s);
    if (!n) return true;

    // Match the starter shown in the supplied HTML.
    const compact = n.replace(/\s+/g, "");
    const starter =
      compact.includes("#include<stdio.h>") &&
      compact.includes("#include<stdlib.h>") &&
      /intmain\(\)\{\}/.test(compact);

    if (starter) return true;

    // Also treat short code containing an empty main as starter.
    return (
      /int\s+main\s*\(\s*\)\s*\{\s*\}/s.test(n) &&
      n.length < 400
    );
  }

  function findMainRange(code) {
    const match = /\bint\s+main\s*\([^)]*\)\s*\{/m.exec(code);
    if (!match) return null;

    const open = code.indexOf("{", match.index);
    if (open < 0) return null;

    let depth = 0;
    let inString = false;
    let inChar = false;
    let lineComment = false;
    let blockComment = false;
    let escaped = false;

    for (let i = open; i < code.length; i++) {
      const c = code[i];
      const n = code[i + 1];

      if (lineComment) {
        if (c === "\n") lineComment = false;
        continue;
      }

      if (blockComment) {
        if (c === "*" && n === "/") {
          blockComment = false;
          i++;
        }
        continue;
      }

      if (inString) {
        if (escaped) {
          escaped = false;
        } else if (c === "\\") {
          escaped = true;
        } else if (c === '"') {
          inString = false;
        }
        continue;
      }

      if (inChar) {
        if (escaped) {
          escaped = false;
        } else if (c === "\\") {
          escaped = true;
        } else if (c === "'") {
          inChar = false;
        }
        continue;
      }

      if (c === "/" && n === "/") {
        lineComment = true;
        i++;
        continue;
      }

      if (c === "/" && n === "*") {
        blockComment = true;
        i++;
        continue;
      }

      if (c === '"') {
        inString = true;
        continue;
      }

      if (c === "'") {
        inChar = true;
        continue;
      }

      if (c === "{") depth++;
      if (c === "}") {
        depth--;
        if (depth === 0) {
          return {
            start: match.index,
            openBrace: open,
            closeBrace: i,
            end: i + 1
          };
        }
      }
    }

    return null;
  }

  function smartMerge(existing, official) {
    existing = normalize(existing);
    official = normalize(official);

    if (!smartMode || looksLikeStarter(existing)) {
      return official;
    }

    const oldMain = findMainRange(existing);
    const newMain = findMainRange(official);

    // If either code does not have a normal main(), use the official
    // solution rather than risking a broken merge.
    if (!oldMain || !newMain) {
      return official;
    }

    // Keep the existing code outside main(), but use the official main().
    const beforeMain = existing.slice(0, oldMain.start).trimEnd();
    const afterMain = existing.slice(oldMain.end).trimStart();

    const officialMain = official
      .slice(newMain.start, newMain.end)
      .trim();

    const pieces = [];
    if (beforeMain) pieces.push(beforeMain);
    pieces.push(officialMain);
    if (afterMain) pieces.push(afterMain);

    return pieces.join("\n\n").trim();
  }

  // Read the current Ace source before changing anything.
  let current = "";
  try {
    current = editor.getSession().getValue();
  } catch (_) {
    try {
      current = editor.getValue();
    } catch (_) {}
  }

  const finalCode = smartMerge(current, solution);

  // Do not rewrite the editor if it already contains the desired code.
  if (normalize(current) === normalize(finalCode)) {
    return;
  }

  // IMPORTANT:
  // SkillRack's change handler compares the Ace value with #txtCode
  // and resets Ace if the increase is >30 characters.
  // Therefore update the hidden textarea FIRST.
  hidden.value = finalCode;

  try {
    hidden.dispatchEvent(
      new Event("input", { bubbles: true })
    );
  } catch (_) {}

  try {
    editor.getSession().setValue(finalCode);
    editor.clearSelection();
    editor.focus();
  } catch (_) {
    try {
      editor.setValue(finalCode, -1);
      editor.clearSelection();
      editor.focus();
    } catch (error) {
      console.error(
        "[SkillRack Auto Filler] Could not set Ace value:",
        error
      );
      return;
    }
  }

  // Keep the backing textarea synchronized after Ace's change event.
  hidden.value = finalCode;

  console.log(
    "[SkillRack Auto Filler] Solution transferred automatically.",
    smartMode && !looksLikeStarter(current)
      ? "Smart merge preserved code outside main()."
      : "Full solution inserted."
  );
}
