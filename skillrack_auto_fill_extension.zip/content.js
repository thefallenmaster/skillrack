
(() => {
  "use strict";

  const SOLUTION_SELECTOR = "#solnC pre";
  const EDITOR_SELECTORS = [
    "#ctracktxtCode.ace_editor",
    "#txtCode"
  ];

  let lastFingerprint = "";
  let timer = null;

  function hashText(text) {
    // Fast deterministic FNV-1a hash; enough for detecting page changes.
    let h = 2166136261;
    for (let i = 0; i < text.length; i++) {
      h ^= text.charCodeAt(i);
      h = Math.imul(h, 16777619);
    }
    return (h >>> 0).toString(16);
  }

  function getSolution() {
    const el = document.querySelector(SOLUTION_SELECTOR);
    if (!el) return "";

    return (el.innerText || el.textContent || "")
      .replace(/\u00a0/g, " ")
      .trim();
  }

  function hasEditor() {
    return EDITOR_SELECTORS.some(
      selector => document.querySelector(selector)
    );
  }

  async function tryClipboardWrite(solution) {
    // This is only a convenience copy. The actual transfer does not depend
    // on the system clipboard.
    try {
      if (navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText(solution);
        return true;
      }
    } catch (_) {}

    try {
      const ta = document.createElement("textarea");
      ta.value = solution;
      ta.style.position = "fixed";
      ta.style.left = "-10000px";
      ta.style.top = "-10000px";
      document.body.appendChild(ta);
      ta.focus();
      ta.select();
      const ok = document.execCommand("copy");
      ta.remove();
      return ok;
    } catch (_) {
      return false;
    }
  }

  function scan() {
    timer = null;

    const solution = getSolution();
    if (!solution || !hasEditor()) return;

    const fingerprint =
      hashText(location.href + "\n" + solution);

    // Avoid repeatedly replacing the editor while Ace emits mutations.
    if (fingerprint === lastFingerprint) return;
    lastFingerprint = fingerprint;

    tryClipboardWrite(solution);

    chrome.runtime.sendMessage({
      type: "SKILLRACK_AUTO_FILL",
      solution,
      smartMode: true
    }).catch(() => {});
  }

  function scheduleScan() {
    if (timer !== null) return;
    timer = setTimeout(scan, 250);
  }

  const observer = new MutationObserver(scheduleScan);

  observer.observe(document.documentElement, {
    subtree: true,
    childList: true,
    attributes: true,
    characterData: true
  });

  window.addEventListener("pageshow", scheduleScan);
  window.addEventListener("load", scheduleScan);

  // Catches late Ace initialization without busy polling.
  setInterval(scan, 1000);

  scheduleScan();
})();
