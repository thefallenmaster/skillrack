
"use strict";

chrome.runtime.onMessage.addListener((message, sender) => {
  if (message?.type !== "FILL_SAVE_RUN") return;

  const tabId = sender?.tab?.id;
  if (typeof tabId !== "number") return;

  chrome.scripting.executeScript({
    target: {
      tabId,
      frameIds: [sender.frameId ?? 0]
    },
    world: "MAIN",
    func: fillSaveRun,
    args: [
      String(message.solution || ""),
      Boolean(message.smartMode)
    ]
  }).catch((error) => {
    console.warn("[SkillRack Helper] executeScript:", error);
  });
});

function fillSaveRun(solution, smartMode) {
  "use strict";

  const hidden = document.getElementById("txtCode");
  if (!hidden || !solution) return;

  let editor = window.txtCode;

  if (!editor &&
      window.ace &&
      typeof window.ace.edit === "function" &&
      document.getElementById("ctracktxtCode")) {
    try {
      editor = window.ace.edit("ctracktxtCode");
    } catch (_) {}
  }

  if (!editor) {
    console.warn("[SkillRack Helper] Ace editor not ready.");
    return;
  }

  // Match the supplied page: remove the bte command that intercepts
  // Ctrl/Cmd clipboard operations.
  try {
    editor.commands.removeCommand("bte");
  } catch (_) {}

  // Match the supplied page's jQuery clipboard bindings.
  try {
    if (window.jQuery) {
      window.jQuery(document).off("cut copy paste");
      window.jQuery(document).off("cut");
      window.jQuery(document).off("copy");
      window.jQuery(document).off("paste");
    }
  } catch (_) {}

  const norm = (value) =>
    (value || "").replace(/\r\n?/g, "\n").trim();

  function isStarter(value) {
    const n = norm(value);
    const c = n.replace(/\s+/g, "");

    return !n ||
      (
        c.includes("#include<stdio.h>") &&
        c.includes("#include<stdlib.h>") &&
        /intmain\(\)\{\}/.test(c)
      ) ||
      (
        n.length < 400 &&
        /int\s+main\s*\(\s*\)\s*\{\s*\}/s.test(n)
      );
  }

  function findMainRange(code) {
    const match = /\bint\s+main\s*\([^)]*\)\s*\{/m.exec(code);
    if (!match) return null;

    const open = code.indexOf("{", match.index);
    if (open < 0) return null;

    let depth = 0;
    let stringMode = false;
    let charMode = false;
    let lineComment = false;
    let blockComment = false;
    let escaped = false;

    for (let i = open; i < code.length; i++) {
      const c = code[i];
      const n = code[i + 1];

      if (lineComment) {
        if (c === "\n") lineComment = false;
        continue;
      }

      if (blockComment) {
        if (c === "*" && n === "/") {
          blockComment = false;
          i++;
        }
        continue;
      }

      if (stringMode) {
        if (escaped) escaped = false;
        else if (c === "\\") escaped = true;
        else if (c === '"') stringMode = false;
        continue;
      }

      if (charMode) {
        if (escaped) escaped = false;
        else if (c === "\\") escaped = true;
        else if (c === "'") charMode = false;
        continue;
      }

      if (c === "/" && n === "/") {
        lineComment = true;
        i++;
        continue;
      }

      if (c === "/" && n === "*") {
        blockComment = true;
        i++;
        continue;
      }

      if (c === '"') {
        stringMode = true;
        continue;
      }

      if (c === "'") {
        charMode = true;
        continue;
      }

      if (c === "{") depth++;

      if (c === "}") {
        depth--;
        if (depth === 0) {
          return {
            start: match.index,
            end: i + 1
          };
        }
      }
    }

    return null;
  }

  function smartMerge(existing, official) {
    existing = norm(existing);
    official = norm(official);

    if (!smartMode || isStarter(existing)) {
      return official;
    }

    const oldMain = findMainRange(existing);
    const newMain = findMainRange(official);

    if (!oldMain || !newMain) {
      return official;
    }

    const before = existing.slice(0, oldMain.start).trimEnd();
    const after = existing.slice(oldMain.end).trimStart();
    const officialMain = official.slice(newMain.start, newMain.end).trim();

    return [before, officialMain, after]
      .filter(Boolean)
      .join("\n\n")
      .trim();
  }

  let current = "";

  try {
    current = editor.getSession().getValue();
  } catch (_) {
    try {
      current = editor.getValue();
    } catch (_) {}
  }

  const finalCode = smartMerge(current, solution);

  if (norm(current) !== norm(finalCode)) {
    // The supplied SkillRack page code resets Ace when its hidden textarea
    // sees a difference >30 chars. Synchronize it first.
    hidden.value = finalCode;

    try {
      hidden.dispatchEvent(
        new Event("input", { bubbles: true })
      );
      hidden.dispatchEvent(
        new Event("change", { bubbles: true })
      );
    } catch (_) {}

    try {
      editor.getSession().setValue(finalCode);
      editor.clearSelection();
      editor.focus();
    } catch (_) {
      try {
        editor.setValue(finalCode, -1);
        editor.clearSelection();
        editor.focus();
      } catch (error) {
        console.error(
          "[SkillRack Helper] Could not set editor:",
          error
        );
        return;
      }
    }

    hidden.value = finalCode;
  }

  const save =
    document.getElementById("j_id_bf") ||
    Array.from(document.querySelectorAll("#btngrp button"))
      .find((button) =>
        (button.innerText || "").trim() === "Save"
      );

  const run =
    document.getElementById("j_id_bg") ||
    Array.from(document.querySelectorAll("#btngrp button"))
      .find((button) =>
        (button.innerText || "").trim() === "Run"
      );

  if (!save || !run) {
    console.warn(
      "[SkillRack Helper] Save/Run buttons not found."
    );
    return;
  }

  function clickButton(button) {
    try {
      button.scrollIntoView({
        block: "center",
        inline: "center"
      });
    } catch (_) {}

    try {
      button.click();
      return true;
    } catch (_) {
      try {
        button.dispatchEvent(
          new MouseEvent("click", {
            bubbles: true,
            cancelable: true,
            view: window
          })
        );
        return true;
      } catch (_) {
        return false;
      }
    }
  }

  // Exact requested sequence: Save, wait for the AJAX operation, then Run.
  if (!clickButton(save)) {
    console.warn("[SkillRack Helper] Save click failed.");
    return;
  }

  console.log("[SkillRack Helper] Save clicked.");

  let waited = 0;

  const runTimer = setInterval(() => {
    waited += 250;

    if (run.disabled || !run.offsetParent) {
      if (waited >= 8000) {
        clearInterval(runTimer);
        console.warn(
          "[SkillRack Helper] Run did not become available."
        );
      }
      return;
    }

    clearInterval(runTimer);

    if (clickButton(run)) {
      console.log("[SkillRack Helper] Run clicked.");
    } else {
      console.warn("[SkillRack Helper] Run click failed.");
    }
  }, 250);
}
