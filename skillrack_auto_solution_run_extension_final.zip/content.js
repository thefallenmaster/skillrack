
(() => {
  "use strict";

  let timer = null;
  let lastSolutionKey = "";
  let lastSubmittedValue = "";
  let lastAttemptAt = 0;
  let busy = false;

  const $ = (selector) => document.querySelector(selector);

  function schedule() {
    if (timer !== null) return;
    timer = setTimeout(() => {
      timer = null;
      scan();
    }, 200);
  }

  function getSolution() {
    const el = $("#solnC pre");
    if (!el) return "";
    return (el.innerText || el.textContent || "")
      .replace(/\u00a0/g, " ")
      .trim();
  }

  function hasEditor() {
    return !!($("#ctracktxtCode.ace_editor") || $("#txtCode"));
  }

  function hasVerification() {
    return !!($("#capval") && $("#proceedbtn"));
  }

  function pageLooksLikeFailure() {
    const body = (document.body?.innerText || "").toLowerCase();
    return /incorrect|wrong|invalid|try again|verification failed/.test(body);
  }

  function handleVerification() {
    const input = $("#capval");
    const proceed = $("#proceedbtn");

    if (!input || !proceed) return;

    try {
      input.focus();
    } catch (_) {}

    const value = (input.value || "").trim();
    if (!value) return;

    // Never submit the same value more than once.
    if (value === lastSubmittedValue) return;

    // Give the page 2 seconds after a reported failed attempt.
    if (pageLooksLikeFailure() && Date.now() - lastAttemptAt < 2000) {
      return;
    }

    if (proceed.disabled || !proceed.offsetParent) return;

    lastSubmittedValue = value;
    lastAttemptAt = Date.now();

    try {
      input.dispatchEvent(new Event("input", { bubbles: true }));
      input.dispatchEvent(new Event("change", { bubbles: true }));
    } catch (_) {}

    try {
      proceed.click();
    } catch (_) {}
  }

  function requestFillAndRun() {
    const solution = getSolution();
    if (!solution || !hasEditor() || busy) return;

    const key = location.href + "\n" + solution;
    if (key === lastSolutionKey) return;

    lastSolutionKey = key;
    busy = true;

    // Convenience clipboard copy only.
    try {
      if (navigator.clipboard?.writeText) {
        navigator.clipboard.writeText(solution).catch(() => {});
      }
    } catch (_) {}

    chrome.runtime.sendMessage({
      type: "FILL_SAVE_RUN",
      solution,
      smartMode: true
    }).catch(() => {
      busy = false;
    });
  }

  function scan() {
    if (hasVerification()) {
      handleVerification();
      return;
    }

    requestFillAndRun();
  }

  const observer = new MutationObserver(schedule);
  observer.observe(document.documentElement, {
    subtree: true,
    childList: true,
    attributes: true,
    characterData: true
  });

  document.addEventListener("input", (event) => {
    if (event.target?.id === "capval") {
      lastSubmittedValue = "";
      schedule();
    }
  }, true);

  document.addEventListener("change", (event) => {
    if (event.target?.id === "capval") {
      lastSubmittedValue = "";
      schedule();
    }
  }, true);

  window.addEventListener("load", schedule);
  window.addEventListener("pageshow", schedule);

  // Lightweight fallback for late PrimeFaces/Ace rendering.
  setInterval(scan, 700);

  schedule();

  console.log("[SkillRack Helper] Loaded.");
})();
