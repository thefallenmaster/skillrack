SkillRack Auto Solution + Run Helper

Based on the supplied SkillRack HTML.

Detected controls:
- Verification input: #capval
- Verification submit: #proceedbtn
- C solution: #solnC pre
- Ace editor: #ctracktxtCode
- Hidden editor backing field: #txtCode
- Save: #j_id_bf
- Run: #j_id_bg

Workflow:
1. Detect #capval and #proceedbtn.
2. Focus #capval automatically.
3. After a value is entered, click Proceed once for that value.
4. On a reported failed attempt, avoid another submission for 2 seconds.
5. Detect #solnC and the editor.
6. Insert the solution directly into Ace.
7. Preserve code outside int main() in smart mode.
8. Save using #j_id_bf.
9. Wait for Save/AJAX to settle.
10. Run using #j_id_bg.
11. Continue detecting again after page refresh/DOM changes.

The verification itself is not calculated or OCRed here. For an owned
staging environment, use a server-side fixed test token/test mode for fully
unattended QA rather than automating a production security challenge.

Install:
- Extract this ZIP.
- Open brave://extensions/
- Enable Developer mode.
- Load unpacked.
- Select the extracted folder.
- Reload SkillRack.
