
"use strict";

chrome.runtime.onMessage.addListener((message, sender) => {
  if (message?.type !== "SKILLRACK_FILL") return;

  const tabId = sender?.tab?.id;
  if (typeof tabId !== "number") return;

  chrome.scripting.executeScript({
    target: {
      tabId,
      frameIds: [sender.frameId ?? 0]
    },
    world: "MAIN",
    func: fillEditor,
    args: [
      String(message.solution ?? ""),
      Boolean(message.smartMode)
    ]
  }).catch(err => console.warn("[SkillRack Helper]", err));
});

function fillEditor(solution, smartMode) {
  const hidden = document.getElementById("txtCode");
  if (!hidden) return;

  let editor = window.txtCode;

  if (!editor &&
      window.ace &&
      typeof window.ace.edit === "function" &&
      document.getElementById("ctracktxtCode")) {
    try {
      editor = window.ace.edit("ctracktxtCode");
    } catch (_) {}
  }

  if (!editor) return;

  // Remove the known Ace blocker installed by the page.
  try { editor.commands.removeCommand("bte"); } catch (_) {}

  // Remove known document-level jQuery clipboard handlers when possible.
  try {
    if (window.jQuery) {
      window.jQuery(document).off("cut copy paste");
      window.jQuery(document).off("cut");
      window.jQuery(document).off("copy");
      window.jQuery(document).off("paste");
    }
  } catch (_) {}

  function norm(s) {
    return (s || "").replace(/\r\n?/g, "\n").trim();
  }

  function starter(s) {
    const n = norm(s);
    const compact = n.replace(/\s+/g, "");
    return !n ||
      (compact.includes("#include<stdio.h>") &&
       compact.includes("#include<stdlib.h>") &&
       /intmain\(\)\{\}/.test(compact)) ||
      (n.length < 400 && /int\s+main\s*\(\s*\)\s*\{\s*\}/s.test(n));
  }

  function findMainRange(code) {
    const m = /\bint\s+main\s*\([^)]*\)\s*\{/m.exec(code);
    if (!m) return null;

    const open = code.indexOf("{", m.index);
    if (open < 0) return null;

    let depth = 0, str = false, chr = false;
    let line = false, block = false, escaped = false;

    for (let i = open; i < code.length; i++) {
      const c = code[i], n = code[i + 1];

      if (line) {
        if (c === "\n") line = false;
        continue;
      }
      if (block) {
        if (c === "*" && n === "/") { block = false; i++; }
        continue;
      }
      if (str) {
        if (escaped) escaped = false;
        else if (c === "\\") escaped = true;
        else if (c === '"') str = false;
        continue;
      }
      if (chr) {
        if (escaped) escaped = false;
        else if (c === "\\") escaped = true;
        else if (c === "'") chr = false;
        continue;
      }

      if (c === "/" && n === "/") { line = true; i++; continue; }
      if (c === "/" && n === "*") { block = true; i++; continue; }
      if (c === '"') { str = true; continue; }
      if (c === "'") { chr = true; continue; }

      if (c === "{") depth++;
      if (c === "}") {
        depth--;
        if (depth === 0) {
          return {
            start: m.index,
            end: i + 1,
            closeBrace: i
          };
        }
      }
    }
    return null;
  }

  function merge(existing, official) {
    existing = norm(existing);
    official = norm(official);

    if (!smartMode || starter(existing)) return official;

    const oldMain = findMainRange(existing);
    const newMain = findMainRange(official);
    if (!oldMain || !newMain) return official;

    const before = existing.slice(0, oldMain.start).trimEnd();
    const after = existing.slice(oldMain.end).trimStart();
    const officialMain = official.slice(newMain.start, newMain.end).trim();

    return [before, officialMain, after]
      .filter(Boolean)
      .join("\n\n")
      .trim();
  }

  let current = "";
  try {
    current = editor.getSession().getValue();
  } catch (_) {
    try { current = editor.getValue(); } catch (_) {}
  }

  const finalCode = merge(current, solution);

  if (norm(current) === norm(finalCode)) return;

  // SkillRack's supplied change handler compares the hidden textarea with
  // the Ace value. Synchronize it before setting Ace to avoid its reset.
  hidden.value = finalCode;

  try {
    hidden.dispatchEvent(new Event("input", {bubbles: true}));
    hidden.dispatchEvent(new Event("change", {bubbles: true}));
  } catch (_) {}

  try {
    editor.getSession().setValue(finalCode);
    editor.clearSelection();
    editor.focus();
  } catch (_) {
    try {
      editor.setValue(finalCode, -1);
      editor.clearSelection();
      editor.focus();
    } catch (err) {
      console.error("[SkillRack Helper] Ace update failed:", err);
      return;
    }
  }

  hidden.value = finalCode;

  console.log("[SkillRack Helper] Solution inserted into editor.");
}
