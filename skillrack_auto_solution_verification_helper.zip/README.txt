SkillRack Auto Solution + Verification Helper
================================================

Use only with authorization on your organization's deployment.

Installation
------------
1. Extract this ZIP.
2. Open brave://extensions/ (or chrome://extensions/).
3. Enable Developer mode.
4. Click "Load unpacked".
5. Select this extension folder.
6. Reload SkillRack.

Automatic behavior
------------------
- Detects #capval and #proceedbtn automatically.
- Focuses #capval as soon as the verification UI appears.
- Once a value is present in #capval, clicks "Proceed to Solve the Program"
  automatically.
- It does NOT calculate, recognize, or bypass the image verification itself.
- After the challenge page loads, detects #solnC pre and the Ace editor.
- Copies solution text to the browser clipboard when permitted.
- Removes the known Ace "bte" clipboard-blocking command.
- Removes the known page-level jQuery clipboard handlers.
- Transfers the solution directly into Ace.
- Updates #txtCode before Ace so the site's >30-character reset logic doesn't
  immediately restore the old source.
- Runs again after refresh, SPA navigation, DOM changes, and late editor load.

Smart insertion
---------------
When the editor is empty/default, the complete official solution is inserted.

When non-default code already exists, the extension preserves code outside
int main() and replaces the main() implementation with the official solution.
