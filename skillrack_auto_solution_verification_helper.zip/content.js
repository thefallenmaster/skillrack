
(() => {
  "use strict";

  let scanTimer = null;
  let lastSolutionFingerprint = "";
  let lastCapSubmitValue = "";

  function schedule() {
    if (scanTimer !== null) return;
    scanTimer = setTimeout(() => {
      scanTimer = null;
      scan();
    }, 200);
  }

  function get(el) {
    return document.querySelector(el);
  }

  function solutionText() {
    const el = get("#solnC pre");
    return el ? (el.innerText || el.textContent || "")
      .replace(/\u00a0/g, " ").trim() : "";
  }

  function hash(s) {
    let h = 2166136261;
    for (let i = 0; i < s.length; i++) {
      h ^= s.charCodeAt(i);
      h = Math.imul(h, 16777619);
    }
    return (h >>> 0).toString(16);
  }

  function captchaDetected() {
    return !!get("#capval") && !!get("#proceedbtn");
  }

  function submitEnteredVerification() {
    const input = get("#capval");
    const button = get("#proceedbtn");
    if (!input || !button) return;

    const value = (input.value || "").trim();
    if (!value) {
      // Focus automatically so the user can enter the value immediately.
      try { input.focus(); } catch (_) {}
      return;
    }

    if (!button.offsetParent || button.disabled) return;
    if (value === lastCapSubmitValue) return;

    lastCapSubmitValue = value;

    // Let page input listeners/PrimeFaces see the current value.
    try {
      input.dispatchEvent(new Event("input", {bubbles: true}));
      input.dispatchEvent(new Event("change", {bubbles: true}));
    } catch (_) {}

    // Submit only after a value is present; this does NOT solve the
    // verification itself.
    try {
      button.click();
    } catch (_) {
      try {
        button.dispatchEvent(new MouseEvent("click", {
          bubbles: true,
          cancelable: true,
          view: window
        }));
      } catch (_) {}
    }
  }

  function detectAndRequestFill() {
    const solution = solutionText();
    if (!solution) return;

    const editor = get("#ctracktxtCode.ace_editor") || get("#txtCode");
    if (!editor) return;

    const fp = hash(location.href + "\n" + solution);
    if (fp === lastSolutionFingerprint) return;
    lastSolutionFingerprint = fp;

    try {
      if (navigator.clipboard?.writeText) {
        navigator.clipboard.writeText(solution).catch(() => {});
      }
    } catch (_) {}

    chrome.runtime.sendMessage({
      type: "SKILLRACK_FILL",
      solution,
      smartMode: true
    }).catch(() => {});
  }

  function scan() {
    if (captchaDetected()) {
      // Automatically focus, but do not calculate/solve the verification.
      try {
        get("#capval").focus();
      } catch (_) {}
      submitEnteredVerification();
    }

    detectAndRequestFill();
  }

  const observer = new MutationObserver(schedule);
  observer.observe(document.documentElement, {
    subtree: true,
    childList: true,
    attributes: true,
    characterData: true
  });

  document.addEventListener("input", (e) => {
    if (e.target?.id === "capval") schedule();
  }, true);

  document.addEventListener("change", (e) => {
    if (e.target?.id === "capval") schedule();
  }, true);

  window.addEventListener("load", schedule);
  window.addEventListener("pageshow", schedule);
  setInterval(scan, 500);

  schedule();

  console.log("[SkillRack Helper] Loaded.");
})();
